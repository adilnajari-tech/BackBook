<?php  
   include('connect.php');
   include('haeder.php');
   
   $query = "SELECT * FROM postes";
   $result = mysqli_query($conn,$query);

   if (isset($result)) {
   	  while($row = mysqli_fetch_assoc($result)){ ?>
<div class="article1">
<h3><a style="color: black;" href="postes.php?id=<?php echo $row['id']; ?>"><?php echo $row['title']; ?> </a></h3>	
<br>
<a href="postes.php?id=<?php echo $row['id']; ?>"><button>Read More</button></a>
</div>
 


<?php

   	  }
   }
?>
</body>
</html>
