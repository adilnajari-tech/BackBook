<?php  
   include('connect.php');
   include('haeder.php');
?>
<!-- about -->
<div class="contaner">
	<h3>About BackBooks</h3>
	<hr>
	<br>
	<p>
		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. 
	</p>
</div>



</body>
</html>