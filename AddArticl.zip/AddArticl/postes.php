<?php  
   include('connect.php');
   include('haeder.php');
   
   
   $id = $_GET['id'];
   $query =  "SELECT * FROM postes WHERE id = ". $id;
   $result = mysqli_query($conn,$query);
   $row = mysqli_fetch_assoc($result);
?>
<div class="article1">
<h3 style="text-align: center;padding: 2px;"> <?php echo $row['title']; ?> </h3>	
<hr>
<br>
<p> <?php echo $row['post']; ?> </p>

</div>
</body>
</html>
