-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- المزود: localhost
-- أنشئ في: 13 أبريل 2020 الساعة 00:34
-- إصدارة المزود: 5.5.16
--  PHP إصدارة: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- قاعدة البيانات: `backbooks`
--

-- --------------------------------------------------------

--
-- بنية الجدول `postes`
--

CREATE TABLE IF NOT EXISTS `postes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `post` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

--
-- إرجاع أو استيراد بيانات الجدول `postes`
--

INSERT INTO `postes` (`id`, `title`, `post`) VALUES
(41, 'hello world', 'hello world programing '),
(42, 'adiladiladiladiladiladiladiladiladil', 'HTML5 and CSS3 and PHP and MYSQLHTML5 and CSS3 and PHP and MYSQLHTML5 and CSS3 and PHP and MYSQL\r\nHTML5 and CSS3 and PHP and MYSQLHTML5 and CSS3 and PHP and MYSQLHTML5 and CSS3 and PHP and MYSQL\r\nHTML5 and CSS3 and PHP and MYSQLHTML5 and CSS3 and PHP and MYSQLHTML5 and CSS3 and PHP and MYSQL\r\nHTML5 and CSS3 and PHP and MYSQLHTML5 and CSS3 and PHP and MYSQL');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
