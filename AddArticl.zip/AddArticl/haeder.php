<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/adpos.css">
	<link rel="icon" href="img/logo.png">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>About Us BackBooks</title>
</head>
<body>
<!-- navbar -->
<nav>
	<div class="nav-warpper">
		<a href="index.php" class="brand-logo">BackBooks</a>
		<ul class="main-menu">
			<li><a href="index.php">Home</a></li>
			<li><a href="add-post.php">Add Post</a></li>
			<li><a href="about.php">About us</a></li>
		</ul>
	</div>
</nav>