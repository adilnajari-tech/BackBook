<?php  
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "backbooks";

$conn = mysqli_connect($hostname,$username,$password,$dbname);
?>