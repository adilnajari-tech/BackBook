<?php  
// CONNECTE DATABASE AND HEADER
   include('connect.php');
// INSERT INFORMITION ON DATABASE
$title    =$_POST['input-title'];
$post     =$_POST['input-post'];
$send     =$_POST['input-send'];
    if (isset($send)) {
    	$query = "INSERT INTO postes(title,post) VALUES('$title','$post')";
    	mysqli_query($conn,$query);
    	header('Location:http://localhost/AddArticl/index.php');
    }
   
?>