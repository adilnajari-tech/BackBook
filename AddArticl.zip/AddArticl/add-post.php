<?php  
   include('haeder.php');
?>
<!-- add post -->
<div class="article">
	<div class="container">
		<h2 style="text-align: center;">Add Post of 250 words</h2>
		<hr>
		<br> 
		<form action="accsebt.php" method="POST">
		<label>Title :</label>
		<input style="margin: 5px 60px;" type="text" name="input-title" required="" placeholder="Enter a Title">
		<br>
		<label>Enter Post :</label>
        <textarea name="input-post" required="" rows="20" cols="120" placeholder="Enter a Post"></textarea>
		<br>
		<button style="margin: 17px 500px;" name="input-send" class="btn">Add Post</button>
		</form>
	</div>
</div>




</body>
</html>